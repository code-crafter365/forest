The ADI_LinearRegulators is a stand-alone tool part of the ADIsimPower tool set for generating power supply designs.

IMPORTANT: You must enable macros when Microsoft Excel asks as the file is being opened.

The tool optimizes the selection of external components based on the user's preference for size, efficiency, and cost.
The tool also includes a standard parametric search that can be used without the optimization feature.

It provides calculated performance data based on the operating conditions and real external components
including ripple, transient response, efficiency, components temperature and much more.

It produces a schematic, bill of materials with real part numbers, and estimated low volume cost for relative comparisons.

Note:  Microsoft Excel is dependent on the language setting Microsoft Windows Operating System for the indication of a decimal point. 
Minor issues may arise when this file is saved using US English notation and then read/run in Excel of another language.  
Changing the decimal notation in the input entries (such as "2.7" to "2,7") should resolve this.
In some cases the OS local language needs to be changed to US English.

We welcome your feedback at: SimPowerTool@analog.com

www.analog.com/ADIsimPower

Analog Devices, Inc.

The following ICs are supported in this file:

ADP120, ADP121, ADP122, ADP123, ADP124, ADP125, ADP130, ADP150, ADP151, ADP160, ADP161, ADP162, ADP163, ADP170, ADP171, ADP172, ADP220, ADP221, ADP223, ADP224, ADP225 ADP320, ADP322, ADP323, ADP1706, ADP1707, ADP1708, ADP1710, ADP1711, ADP1712, ADP1713, ADP1714, ADP1715, ADP1716, ADP1720, ADP1740, ADP1741, ADP1752, ADP1753, ADP1754, ADP1755, ADP2140, ADP3300, ADP3301, ADP3303, ADP3309, ADP3330, ADP3331, ADP3333, ADP3334, ADP3335, ADP3336, ADP3338, ADP3339, ADP3367, ADP667, ADP7102, ADP7104, ADP7182, ADP7105, ADM7160, ADM7150, ADM7151 